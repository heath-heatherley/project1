﻿namespace FINAL_PROJECT
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.convertFromComboBox = new System.Windows.Forms.ComboBox();
            this.convertToComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.passportRadioButton = new System.Windows.Forms.RadioButton();
            this.cashRadioButton = new System.Windows.Forms.RadioButton();
            this.checkRateButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Amount:";
            // 
            // amountTextBox
            // 
            this.amountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amountTextBox.Location = new System.Drawing.Point(24, 32);
            this.amountTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(132, 24);
            this.amountTextBox.TabIndex = 1;
            this.amountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // convertFromComboBox
            // 
            this.convertFromComboBox.FormattingEnabled = true;
            this.convertFromComboBox.Items.AddRange(new object[] {
            "USD",
            "EUR",
            "GBP"});
            this.convertFromComboBox.Location = new System.Drawing.Point(208, 31);
            this.convertFromComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.convertFromComboBox.Name = "convertFromComboBox";
            this.convertFromComboBox.Size = new System.Drawing.Size(160, 24);
            this.convertFromComboBox.TabIndex = 2;
            this.convertFromComboBox.Text = "---Convert From---";
            // 
            // convertToComboBox
            // 
            this.convertToComboBox.FormattingEnabled = true;
            this.convertToComboBox.Items.AddRange(new object[] {
            "USD",
            "EUR",
            "GBP"});
            this.convertToComboBox.Location = new System.Drawing.Point(208, 81);
            this.convertToComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.convertToComboBox.Name = "convertToComboBox";
            this.convertToComboBox.Size = new System.Drawing.Size(160, 24);
            this.convertToComboBox.TabIndex = 3;
            this.convertToComboBox.Text = "---Convert To---";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.passportRadioButton);
            this.groupBox1.Controls.Add(this.cashRadioButton);
            this.groupBox1.Font = new System.Drawing.Font("Cooper Black", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 96);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(171, 107);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment Method";
            // 
            // passportRadioButton
            // 
            this.passportRadioButton.AutoSize = true;
            this.passportRadioButton.Location = new System.Drawing.Point(8, 63);
            this.passportRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.passportRadioButton.Name = "passportRadioButton";
            this.passportRadioButton.Size = new System.Drawing.Size(137, 21);
            this.passportRadioButton.TabIndex = 1;
            this.passportRadioButton.TabStop = true;
            this.passportRadioButton.Text = "Cash Passport";
            this.passportRadioButton.UseVisualStyleBackColor = true;
            // 
            // cashRadioButton
            // 
            this.cashRadioButton.AutoSize = true;
            this.cashRadioButton.Location = new System.Drawing.Point(8, 34);
            this.cashRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.cashRadioButton.Name = "cashRadioButton";
            this.cashRadioButton.Size = new System.Drawing.Size(66, 21);
            this.cashRadioButton.TabIndex = 0;
            this.cashRadioButton.TabStop = true;
            this.cashRadioButton.Text = "Cash";
            this.cashRadioButton.UseVisualStyleBackColor = true;
            // 
            // checkRateButton
            // 
            this.checkRateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkRateButton.Location = new System.Drawing.Point(231, 129);
            this.checkRateButton.Margin = new System.Windows.Forms.Padding(4);
            this.checkRateButton.Name = "checkRateButton";
            this.checkRateButton.Size = new System.Drawing.Size(115, 33);
            this.checkRateButton.TabIndex = 5;
            this.checkRateButton.Text = "Check &Rate";
            this.checkRateButton.UseVisualStyleBackColor = true;
            this.checkRateButton.Click += new System.EventHandler(this.checkRateButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(231, 170);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(4);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(115, 33);
            this.cancelButton.TabIndex = 6;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // MainForm
            // 
            this.AcceptButton = this.checkRateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FINAL_PROJECT.Properties.Resources.EUR_USD_2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(393, 251);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.checkRateButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.convertToComboBox);
            this.Controls.Add(this.convertFromComboBox);
            this.Controls.Add(this.amountTextBox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "Al\'s Easy Money";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button checkRateButton;
        public System.Windows.Forms.TextBox amountTextBox;
        public System.Windows.Forms.ComboBox convertFromComboBox;
        public System.Windows.Forms.ComboBox convertToComboBox;
        public System.Windows.Forms.RadioButton passportRadioButton;
        public System.Windows.Forms.RadioButton cashRadioButton;
        public System.Windows.Forms.Button cancelButton;
    }
}

