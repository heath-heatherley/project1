﻿namespace FINAL_PROJECT
{
    partial class ConversionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buyButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.conversionRateLabel = new System.Windows.Forms.Label();
            this.convertFromLabel = new System.Windows.Forms.Label();
            this.convertToLabel = new System.Windows.Forms.Label();
            this.cashPassportFeeLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buyButton
            // 
            this.buyButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buyButton.Location = new System.Drawing.Point(72, 225);
            this.buyButton.Margin = new System.Windows.Forms.Padding(4);
            this.buyButton.Name = "buyButton";
            this.buyButton.Size = new System.Drawing.Size(100, 28);
            this.buyButton.TabIndex = 0;
            this.buyButton.Text = "&Buy";
            this.buyButton.UseVisualStyleBackColor = true;
            this.buyButton.Click += new System.EventHandler(this.buyButton_Click);
            // 
            // backButton
            // 
            this.backButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(213, 225);
            this.backButton.Margin = new System.Windows.Forms.Padding(4);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(100, 28);
            this.backButton.TabIndex = 1;
            this.backButton.Text = "Ba&ck";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Conversion Rate: ";
            // 
            // conversionRateLabel
            // 
            this.conversionRateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conversionRateLabel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.conversionRateLabel.Location = new System.Drawing.Point(147, 11);
            this.conversionRateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.conversionRateLabel.Name = "conversionRateLabel";
            this.conversionRateLabel.Size = new System.Drawing.Size(192, 26);
            this.conversionRateLabel.TabIndex = 3;
            this.conversionRateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // convertFromLabel
            // 
            this.convertFromLabel.BackColor = System.Drawing.Color.Linen;
            this.convertFromLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.convertFromLabel.Font = new System.Drawing.Font("Cooper Black", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertFromLabel.Location = new System.Drawing.Point(41, 74);
            this.convertFromLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.convertFromLabel.Name = "convertFromLabel";
            this.convertFromLabel.Size = new System.Drawing.Size(272, 28);
            this.convertFromLabel.TabIndex = 6;
            this.convertFromLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // convertToLabel
            // 
            this.convertToLabel.BackColor = System.Drawing.Color.Linen;
            this.convertToLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.convertToLabel.Font = new System.Drawing.Font("Cooper Black", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertToLabel.Location = new System.Drawing.Point(41, 128);
            this.convertToLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.convertToLabel.Name = "convertToLabel";
            this.convertToLabel.Size = new System.Drawing.Size(272, 28);
            this.convertToLabel.TabIndex = 7;
            this.convertToLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cashPassportFeeLabel
            // 
            this.cashPassportFeeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashPassportFeeLabel.Location = new System.Drawing.Point(41, 178);
            this.cashPassportFeeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cashPassportFeeLabel.Name = "cashPassportFeeLabel";
            this.cashPassportFeeLabel.Size = new System.Drawing.Size(297, 23);
            this.cashPassportFeeLabel.TabIndex = 8;
            this.cashPassportFeeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ConversionForm
            // 
            this.AcceptButton = this.buyButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Wheat;
            this.CancelButton = this.backButton;
            this.ClientSize = new System.Drawing.Size(416, 299);
            this.Controls.Add(this.cashPassportFeeLabel);
            this.Controls.Add(this.convertToLabel);
            this.Controls.Add(this.convertFromLabel);
            this.Controls.Add(this.conversionRateLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.buyButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ConversionForm";
            this.Text = "Al\'s Easy Money";
            this.Load += new System.EventHandler(this.ConversionForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buyButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label conversionRateLabel;
        public System.Windows.Forms.Label convertFromLabel;
        public System.Windows.Forms.Label convertToLabel;
        public System.Windows.Forms.Label cashPassportFeeLabel;
    }
}