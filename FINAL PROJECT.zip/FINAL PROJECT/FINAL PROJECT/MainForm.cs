﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace FINAL_PROJECT
{
    public partial class MainForm : Form
    {
        //create new variable to hold ConversionForm object to display results
        ConversionForm convertForm = new ConversionForm(); 
        public MainForm()
        {
            InitializeComponent();
        }

        

        private decimal GetAmount(double exchange, decimal inputAmount) //method to calculate exchange amount
        {
            decimal amount = (decimal)exchange * inputAmount;

            return amount;
        }

        public void DisplayFromLabel(string from, decimal amount, string cFrom) //method to display from currency original amount
        {
            convertForm.convertFromLabel.Text = $"Amount in {from.ToString()}: {amount.ToString("c", CultureInfo.CreateSpecificCulture(cFrom))}";
        }
        public void DisplayToLabel(string to, decimal amount, string cTo)//method to display new converted currency amount
        {
            convertForm.convertToLabel.Text = $"Amount in {to.ToString()}: {amount.ToString("c", CultureInfo.CreateSpecificCulture(cTo))}";
        }
        public void DisplayConversionRate(string from, double exchange, string to) //method to display conversion rate
        {
            convertForm.conversionRateLabel.Text = $"1 {from.ToString()} = {exchange.ToString()} {to.ToString()}";
        }

        private decimal PassportFee(decimal amount) //method to calculate passport fee
        {
            decimal totalFee = amount * 0.02m;

            return totalFee;
        }

        private void checkRateButton_Click(object sender, EventArgs e)
        {
            
            decimal amount; //variable to hold amount entered by user
            string from, to; //variables to hold combobox selections
            double exchangeRate = 0; //variable to hold exchange rate 
            string fromCurrency = "en-US", toCurrency = "en-GB"; //variables to hold currnency type

            if(int.TryParse(amountTextBox.Text, out int input)) //validating text
            {
                amount = input; //putting user input into decimal amount
                
                //setting convert from/to selections
                from = convertFromComboBox.SelectedItem.ToString();
                to = convertToComboBox.SelectedItem.ToString();

                decimal getAmount = 0m; //creating variable to hold returned value from method

                if (from != to) //
                {
                    if(from=="USD" && to == "EUR")//convert USD to EUR
                    {
                        //setting exchange rate and currency used
                        exchangeRate = 0.94;
                        fromCurrency = "en-US";
                        toCurrency = "fr-FR";
                        getAmount = GetAmount(exchangeRate, amount); //calculating exchange amount
                        //displaying results to convert Form
                        DisplayFromLabel(from, amount, fromCurrency);
                        DisplayToLabel(to, getAmount, toCurrency);
                        DisplayConversionRate(from, exchangeRate, to);

                    }
                    else if(from=="USD" && to == "GBP")//convert USD to GBP
                    {
                        exchangeRate = 0.79;
                        fromCurrency = "en-US";
                        toCurrency = "en-GB";
                        getAmount = GetAmount(exchangeRate, amount); //calculating exchange amount
                        //displaying results to convert Form
                        DisplayFromLabel(from, amount, fromCurrency);
                        DisplayToLabel(to, getAmount, toCurrency);
                        DisplayConversionRate(from, exchangeRate, to);
                    }
                    else if (from == "EUR" && to == "USD")//convert EUR to USD
                    {
                        exchangeRate = 1.06;
                        fromCurrency = "fr-FR";
                        toCurrency = "en-US";
                        getAmount = GetAmount(exchangeRate, amount); //calculating exchange amount
                        //displaying results to convert Form
                        DisplayFromLabel(from, amount, fromCurrency);
                        DisplayToLabel(to, getAmount, toCurrency);
                        DisplayConversionRate(from, exchangeRate, to);
                    }
                    else if (from == "EUR" && to == "GBP")//convert EUR to GBP
                    {
                        exchangeRate = 0.85;
                        fromCurrency = "en-US";
                        toCurrency = "en-GB";
                        getAmount = GetAmount(exchangeRate, amount); //calculating exchange amount
                        //displaying results to convert Form
                        DisplayFromLabel(from, amount, fromCurrency);
                        DisplayToLabel(to, getAmount, toCurrency);
                        DisplayConversionRate(from, exchangeRate, to);
                    }
                    else if (from == "GBP" && to == "USD")//convert GBP to USD
                    {
                        exchangeRate = 1.25;
                        fromCurrency = "en-GB";
                        toCurrency = "en-US";
                        getAmount = GetAmount(exchangeRate, amount); //calculating exchange amount
                        //displaying results to convert Form
                        DisplayFromLabel(from, amount, fromCurrency);
                        DisplayToLabel(to, getAmount, toCurrency);
                        DisplayConversionRate(from, exchangeRate, to);
                    }
                    else if (from == "GBP" && to == "EUR")//convert GBP to EUR
                    {
                        exchangeRate = 1.17;
                        fromCurrency = "en-GB";
                        toCurrency = "fr-FR";
                        getAmount = GetAmount(exchangeRate, amount); //calculating exchange amount
                        //displaying results to convert Form
                        DisplayFromLabel(from, amount, fromCurrency);
                        DisplayToLabel(to, getAmount, toCurrency);
                        DisplayConversionRate(from, exchangeRate, to);
                    }

                    if (passportRadioButton.Checked)//calculating & displaying pasport fee
                    {
                        decimal fee = PassportFee(amount);
                        convertForm.cashPassportFeeLabel.Text = $"Additional Passport Fee: {fee.ToString("c", CultureInfo.CreateSpecificCulture(fromCurrency))}";
                    }

                    convertForm.ShowDialog(); //showing results on Conversion Form
                    //reseting form to starting format
                    amountTextBox.Clear();
                    cashRadioButton.Focus();
                    convertFromComboBox.SelectedIndex = 0;
                    convertToComboBox.SelectedIndex = 1;
                }
                else
                {
                    MessageBox.Show("Must select two different currency types.");//error message
                }
            }
            else
            {
                MessageBox.Show("Invalid Amount Entry.");//error message
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            //reseting form to starting format
            amountTextBox.Clear();
            cashRadioButton.Focus();
            convertFromComboBox.SelectedIndex = 0;
            convertToComboBox.SelectedIndex = 1;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //setting focus to cash radio button
            cashRadioButton.Focus();
            //setting combo box to correct starting points
            convertFromComboBox.SelectedIndex = 0;
            convertToComboBox.SelectedIndex = 1;
        }
    }
}
