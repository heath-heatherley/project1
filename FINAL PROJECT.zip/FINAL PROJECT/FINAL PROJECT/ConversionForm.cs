﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.IO;

namespace FINAL_PROJECT
{
    public partial class ConversionForm : Form
    {



        public ConversionForm()
        {
            InitializeComponent();
        }
        public ConversionForm(MainForm home)
        {
            InitializeComponent();
            
           
        }

        //MainForm home;

        private int trNumber = 1;
        

        private void buyButton_Click(object sender, EventArgs e)
        {
            //MainForm home = new MainForm();

            string originalAmount = convertFromLabel.Text; //original amount
            string exchangeRate = conversionRateLabel.Text; //exchange rate
            string newAmount = convertToLabel.Text; //new amount
            string passportFee = cashPassportFeeLabel.Text;//passport fee
            string passportCode = ""; //passport code for passport w/cash purchase

            //setting transaction number
            trNumber++;
            
            

            if (cashPassportFeeLabel.Text == "")
            {
                MessageBox.Show($"Transaction Complete!"); //Message for user success

                try
                {
                    Encoding encoding = Encoding.GetEncoding("utf-16"); //sets the encoding
                    //opens the file for appending
                    FileStream myFile = new FileStream("FXTsn.txt", FileMode.Append);
                    //sets the encoding scheme to the file
                    StreamWriter outFile = new StreamWriter(myFile, encoding);
                    //writing purchase to file
                    outFile.WriteLine($"{originalAmount}\t\t{exchangeRate}\t{newAmount}");
                    outFile.Close();//closing file
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);//error message
                }
            }
            else
            {
                //random object created for passport code
                Random rand = new Random();
                
                //for loop to create random passcode
                for (int index = 0; index < 16; index++)
                {
                    passportCode += rand.Next(10);
                }
                MessageBox.Show($"Transaction Complete!\n{passportFee}\nPassport Code: {passportCode}"); //Message for user success

                try
                {
                    Encoding encoding = Encoding.GetEncoding("utf-16"); //sets the encoding
                    //opens the file for appending
                    FileStream myFile = new FileStream("FXTsn.txt", FileMode.Append);
                    //sets the encoding scheme to the file
                    StreamWriter outFile = new StreamWriter(myFile, encoding);
                    //writing purchase to file
                    outFile.WriteLine($"{originalAmount}\t\t{exchangeRate}\t{newAmount}\t\t{passportFee}\t\t{passportCode}");
                    outFile.Close(); //closing file
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);//error message
                }
            }

            //home.amountTextBox.Clear();
            //home.cashRadioButton.Focus();
            //home.convertFromComboBox.SelectedIndex = 0;
            //home.convertToComboBox.SelectedIndex = 1;
            this.Close(); //closing form
            //setting transaction number to form label
            this.Text = $"Transaction Number: {trNumber.ToString()}";
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            //closing this form
            this.Close();
        }

        private void ConversionForm_Load(object sender, EventArgs e)
        {
            //setting form label to display transaction number upon loading
            this.Text = $"Transaction Number: {trNumber.ToString()}";
        }
    }
}
